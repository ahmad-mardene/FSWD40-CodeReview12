<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Mount_Everest
 */

?>

    <footer class="container-fluid row">
    	<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
    		Our Partners:<br>
    		<a href="#">First Partner</a><br>
    		<a href="#">Second Partner</a><br>
    		<a href="#">Third Partner</a><br>
    		
    	</div>
    	<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
    		Jobs:<br>
    		<a href="#">First Job</a><br>
    		<a href="#">Second Job</a><br>
    		<a href="#">Third Job</a><br>
    		<a href="#">Fourth Job</a><br>
    	</div>
    	<div class="row col-lg-6 col-md-6 col-sm-6 col-xs-12">
    		
    		<div class="row col-lg-6 col-md-12 col-sm-12 col-xs-12">
    			Send us a Comment:
    			<input type="text" class="form-control"  placeholder="Your name">
    			<input type="email" class="form-control"  placeholder="Email Address">
			     <button type="submit" class="btn">Submit</button>
    			
    		</div class="row col-lg-6 col-md-12 col-sm-12 col-xs-12">
    		<div class="form-group">
			    <label for="exampleFormControlTextarea1">Your Comment:</label>
			    <textarea class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
			    <div class="form-check">
			    <input type="checkbox" class="form-check-input" id="exampleCheck1">
			    <label class="form-check-label" for="exampleCheck1">Get Emails About it</label>
			  </div>
			  
			 </div>

    	</div>


    	
    </footer>

<?php wp_footer(); ?>

</body>
</html>
